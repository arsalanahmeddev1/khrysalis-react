import AppRouter from "./router";
import 'react-loading-skeleton/dist/skeleton.css'
import "./App.css";


const App = () => <AppRouter />;

export default App;
