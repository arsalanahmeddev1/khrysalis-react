const LineDivider = () => <hr className="my-8 bg-white opacity-10" />;

export default LineDivider;
